// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2026-07-13
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************
function integer BW_LPI_DATA;
	input integer burden;
  input integer parcel;
begin
  BW_LPI_DATA = burden + parcel;
end
endfunction

function integer BW_LPI_QCH;
  input integer burden;
  input integer parcel;
	input integer bw_data;
begin
  BW_LPI_QCH = 1 + BW_LPI_DATA(burden, parcel); 
end
endfunction

function integer BW_LPI_YCH;
  input integer burden;
  input integer parcel;
	input integer bw_data;
begin
  BW_LPI_YCH = 1 + BW_LPI_DATA(burden, parcel); 
end
endfunction
