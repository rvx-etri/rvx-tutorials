// ****************************************************************************
// ****************************************************************************
// Copyright SoC Design Research Group, All rights reservxd.
// Electronics and Telecommunications Research Institute (ETRI)
// 
// THESE DOCUMENTS CONTAIN CONFIDENTIAL INFORMATION AND KNOWLEDGE
// WHICH IS THE PROPERTY OF ETRI. NO PART OF THIS PUBLICATION IS
// TO BE USED FOR ANY OTHER PURPOSE, AND THESE ARE NOT TO BE
// REPRODUCED, COPIED, DISCLOSED, TRANSMITTED, STORED IN A RETRIEVAL
// SYSTEM OR TRANSLATED INTO ANY OTHER HUMAN OR COMPUTER LANGUAGE,
// IN ANY FORM, BY ANY MEANS, IN WHOLE OR IN PART, WITHOUT THE
// COMPLETE PRIOR WRITTEN PERMISSION OF ETRI.
// ****************************************************************************
// 2026-07-13
// Kyuseung Han (han@etri.re.kr)
// ****************************************************************************
// ****************************************************************************

`include "ervp_global.vh"
`include "ervp_axi_define.vh"





module RVX_MODULE_039
(
	rvx_port_13,
	rvx_port_03,
  rvx_port_15,
  rvx_port_23,

  rvx_port_25,
  rvx_port_14,
  rvx_port_00,
  rvx_port_18,
  rvx_port_10,
  rvx_port_24,

  rvx_port_05,
  rvx_port_22,
  rvx_port_08,
  rvx_port_07,
  rvx_port_02,

  rvx_port_06,
  rvx_port_11,
  rvx_port_20,
  rvx_port_01,
  rvx_port_21,
  rvx_port_04,

  rvx_port_16,
  rvx_port_09,
  rvx_port_19,
  rvx_port_17,
  rvx_port_12
);





parameter RVX_GPARA_2 = 32;
parameter RVX_GPARA_1 = 32;
parameter RVX_GPARA_3 = 16;
parameter RVX_GPARA_0 = 16;

input wire rvx_port_13;
input wire rvx_port_03;
input wire rvx_port_15;
input wire rvx_port_23;

output wire [2-1:0] rvx_port_25;
input wire rvx_port_14;
input wire rvx_port_00;
input wire rvx_port_18;
input wire rvx_port_10;
input wire [RVX_GPARA_2-1:0] rvx_port_24;

input wire [2-1:0] rvx_port_05;
output wire rvx_port_22;
output wire rvx_port_08;
output wire rvx_port_07;
output wire [RVX_GPARA_1-1:0] rvx_port_02;

input wire [2-1:0] rvx_port_06;
output wire rvx_port_11;
output wire rvx_port_20;
output wire rvx_port_01;
output wire rvx_port_21;
output wire [RVX_GPARA_2-1:0] rvx_port_04;

output wire [2-1:0] rvx_port_16;
input wire rvx_port_09;
input wire rvx_port_19;
input wire rvx_port_17;
input wire [RVX_GPARA_1-1:0] rvx_port_12;

localparam  RVX_LPARA_0 = 1 + 1 + 1 + RVX_GPARA_2;

wire [2-1:0] rvx_signal_1;
wire rvx_signal_2;
wire [RVX_LPARA_0-1:0] rvx_signal_5;
wire rvx_signal_0;
wire rvx_signal_3;
wire [RVX_LPARA_0-1:0] rvx_signal_4;

ERVP_FIFO
#(
  .BW_DATA(RVX_LPARA_0),
  .DEPTH(RVX_GPARA_3),
  .WRITE_READY_SIZE(2)
)
i_rvx_instance_0
(
  .clk(rvx_port_13),
  .rstnn(rvx_port_03),
  .enable(rvx_port_23),
  .clear(rvx_port_15),
  .wready(rvx_signal_1),
  .wfull(),
  .wrequest(rvx_signal_2),
  .wdata(rvx_signal_5),
  .wnum(),
  .rready(rvx_signal_0),
  .rempty(),
  .rrequest(rvx_signal_3),
  .rdata(rvx_signal_4),
  .rnum()
);

assign rvx_port_25 = rvx_signal_1;
assign rvx_signal_2 = rvx_port_14;
assign rvx_signal_5 = {rvx_port_00, rvx_port_18, rvx_port_10, rvx_port_24};

assign rvx_port_11 = rvx_signal_0;
assign {rvx_port_20, rvx_port_01, rvx_port_21, rvx_port_04} = rvx_signal_4;
assign rvx_signal_3 = rvx_port_06[0];

assign rvx_port_16 = rvx_port_05;
assign rvx_port_22 = rvx_port_09;
assign rvx_port_08 = rvx_port_19;
assign rvx_port_07 = rvx_port_17;
assign rvx_port_02 = rvx_port_12;

endmodule
