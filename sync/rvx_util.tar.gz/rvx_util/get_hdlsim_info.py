def get_hdlsim_filename(tool: str, action: str) -> str:
    action_list = action.split('.')
    result = None
    assert len(action_list) == 2, action
    if 0:
        pass
    elif tool == 'ncsim' or tool == 'xcelium':
        if 0:
            pass
        elif action_list[0] == 'compile':
            if 0:
                pass
            elif action_list[1] == 'log':
                result = 'xmvlog.log'
            else:
                assert 0
        elif action_list[0] == 'elaborate':
            if 0:
                pass
            elif action_list[1] == 'log':
                result = 'xmelab.log'
            else:
                assert 0
        elif action_list[0] == 'run' or action_list[0] == 'debug':
            if 0:
                pass
            elif action_list[1] == 'log':
                result = 'xmsim.log'
            else:
                assert 0
    elif tool == 'modelsim' or tool == 'questasim':
        if 0:
            pass
        elif action_list[0] == 'compile':
            assert 0
        elif action_list[0] == 'elaborate':
            assert 0
        elif action_list[0] == 'run' or action_list[0] == 'debug':
            if 0:
                pass
            elif action_list[1] == 'log':
                result = 'qtsim.log'
            else:
                assert 0
                
    assert result, (tool, action)
    return result
