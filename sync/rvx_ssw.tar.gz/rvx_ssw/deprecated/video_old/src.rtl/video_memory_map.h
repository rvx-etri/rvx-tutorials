#ifndef _H_VIDEO_MEMORY_MAP_H_
#define _H_VIDEO_MEMORY_MAP_H_

#define VIM_BASE        (VIDEO_CTRL_BASEADDR)
#define VOM_BASE        (VIDEO_CTRL_BASEADDR + 0x10000)

#endif
