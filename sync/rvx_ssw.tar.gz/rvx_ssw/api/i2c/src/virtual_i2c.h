#ifndef __H_VIRTUAL_I2C_H__
#define __H_VIRTUAL_I2C_H__

#define VIRTUAL_I2C_MODULE_ADDR		(0x48)

void config_virutal_i2c(int index);
void test_virutal_i2c(int index);

#endif
