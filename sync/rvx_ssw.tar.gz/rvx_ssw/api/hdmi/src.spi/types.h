#ifndef _H_TYPES_H_
#define _H_TYPES_H_


typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;


typedef struct {
	unsigned short reg;
	unsigned short val;
} sensor_reg;


#endif