#ifndef __TYPES_H__
#define __TYPES_H__


typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;


typedef struct {
	unsigned short reg;
	unsigned short val;
} sensor_reg;


#endif
