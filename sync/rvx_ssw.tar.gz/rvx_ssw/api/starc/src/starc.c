#include "ervp_printf.h"
#include "ervp_assert.h"
#include "ervp_bit_util.h"

#include "dca_matrix_info.h"
#include "starc.h"
#include "starc_support.h"

#define MAX_CORE_INPUT_SIZE 128

typedef struct {
	dca_matrix_info_t spikein;
	dca_matrix_info_t weight;
	dca_matrix_info_t spikeout;
	unsigned int num_step_merged_m1 : 16;
	unsigned int num_spike_allowed : 15;
	unsigned int neuron_reset_type : 1;
	unsigned int opcode : 8;
} starc_inst_t;

void starc_hwinfo_elaborate(starc_hwpara_t *hwpara, starc_hwinfo_t *hwinfo)
{
	static int id_to_issue = 0;
	hwinfo->core_input_size = hwpara->core_input_size;
	hwinfo->core_output_size = hwpara->core_output_size;
	hwinfo->bw_weight = hwpara->bw_weight;
	hwinfo->capacitance = 0;
	hwinfo->id = id_to_issue++;
}

static inline void starc_set_layer_threshold(const starc_hwinfo_t* hwinfo, const ervp_starc_option_t* options)
{
	uint32_t formatted_threshold[MAX_CORE_INPUT_SIZE];
	unsigned int remaining_threshold;
	unsigned int weight_max = starc_get_weight_max(hwinfo);
	assert(hwinfo->core_input_size<=MAX_CORE_INPUT_SIZE);
	remaining_threshold = weight_max;
	if(options!=NULL)
		if(options->threshold!=0)
			remaining_threshold = options->threshold;

	for(int i=0; i<hwinfo->core_input_size; i++)
	{
		unsigned int value;
		if(remaining_threshold==0)
			formatted_threshold[i] = 0;
		else
		{
			if(remaining_threshold>=weight_max)
				value = weight_max;
			else
				value = remaining_threshold;
			formatted_threshold[i] = convert_sign_and_magnitude(-value,hwinfo->bw_weight);
			remaining_threshold -= value;
		}
	}
	assert(remaining_threshold==0);
	mmiox1_input_push(hwinfo->mmiox_info, formatted_threshold, 1);
}

void starc_inference_request(const starc_hwinfo_t* hwinfo, const ervp_starc_option_t* options, const ErvpMatrixInfo *spikein_info, const ErvpMatrixInfo *weight_info, ErvpMatrixInfo *spikeout_info)
{
	const ErvpMatrixInfo *converted_weight_info;
	starc_inst_t inst;
	unsigned int num_step_merged_m1;

	starc_set_layer_threshold(hwinfo, options);
	converted_weight_info = starc_convert_weight(hwinfo, weight_info);
	dca_generate_matrix_info(spikein_info, &(inst.spikein));
	dca_generate_matrix_info(converted_weight_info, &(inst.weight));
	dca_generate_matrix_info(spikeout_info, &(inst.spikeout));
	if(options==NULL)
	{
		inst.num_step_merged_m1 = 0;
		inst.num_spike_allowed = hwinfo->core_input_size;
		inst.neuron_reset_type = 0;
	}
	else
	{
		inst.num_step_merged_m1 = options->num_step_merged_m1;
		inst.num_spike_allowed = starc_analyze_num_spike_allowed(hwinfo, weight_info, options);
		inst.neuron_reset_type  = options->neuron_reset_type;
	}
	mmiox1_inst_push(hwinfo->mmiox_info, &inst, 1, 0);
}

void starc_print_info(const starc_hwinfo_t* hwinfo)
{
	mmiox1_print_info(hwinfo->mmiox_info);
}
