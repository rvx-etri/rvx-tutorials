#ifndef __STARC_SUPPORT_H__
#define __STARC_SUPPORT_H__

#include "ervp_matrix.h"
#include "ervp_math.h"
#include "starc.h"

static inline unsigned int starc_get_weight_max(const starc_hwinfo_t* hwinfo)
{
	return math_exp_uint(2,hwinfo->bw_weight-1)-1;
}

const ErvpMatrixInfo* starc_convert_weight(const starc_hwinfo_t* hwinfo, const ErvpMatrixInfo *weight_info);
unsigned int starc_analyze_num_spike_allowed(const starc_hwinfo_t* hwinfo, const ErvpMatrixInfo *weight_info, const ervp_starc_option_t* options);

#endif