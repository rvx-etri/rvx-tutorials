#ifndef __ERVP_OLEDBW_PRINTF_H__
#define __ERVP_OLEDBW_PRINTF_H__

void oledbw_putc(char c);

#endif
