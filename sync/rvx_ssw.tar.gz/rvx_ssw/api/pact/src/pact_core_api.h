#ifndef __PACT_CORE_API_H__
#define __PACT_CORE_API_H__

void pact_core0_init();
void pact_core0_start(void* start_addr);
void pact_core0_wait();

#endif
